In order to configure your re-fillerator with Amazon Dash replenishment Services,
firstly, make sure the success.html and LWA.html files are contained within a folder
called "templates". Next, run the Refillerator.py file. You can then open the page 
with the given webhost. You will be promted to an errorpage, click "advanced" and then
"proceed to 127.0.0.1(unsafe)". You will then go on and register the fridge with Amazon
Dash replenishment services and choose which items you want to be replenished automatically
in the given slots. You will also provide a method of payment in order for it to be purchased.
To be able to see live sensor data, and activate the "close door" audio signifier for when 
the fridge door is open for too long, paste the project.json file in node red and deploy
the project. This is how I have opened the card-board I have made in IBM Watson's IoT service.