#*************************************#
# This program will assist a          #
# re-fillerator customer in setting   #
# their fridgerator up with Amazon    #
# Dash Replenishment Services         #
#*************************************#
# Author: Elham Jmaileh                #
# Date: March 14, 2020                #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#


# Import the GrovePi+ libraries
from grovepi import*
from grove_rgb_lcd import *
import time
# Import flask libraries
from flask import Flask, render_template, redirect, jsonify


#Here is where the two LED variables are initialized as well as the 
#force sensor
LED1 = 8
LED2 = 7
force_Sensor = 0
pinMode(LED1,  "OUTPUT")
pinMode(LED2, "OUTPUT")

# flask constructor for taking the current module
# as an argument
app = Flask(__name__)



# Routing in Flask
# *************************************
# flask uses a routing technique for
# enabling the user to remember URLs
# of applications (eg. similar to REST)
# You can then access the page directly
# with no further navigation
    
@app.route('/')
def index():
    return render_template('LWA.html')
    
 # This value could be used to read immediate values from the force sensor.
 # With this value, we can use AJAX to trigger the replenish page
 # if the value is beloew 20 for example.   
@app.route("/getForce")
def getForce():
    force = analogRead(0)
    return str(force)
    
    
# Here we are routing to the login with Amazon page where we will initilize
# replenishment settings of our device
@app.route('/LWA')
def reOrder():
    setText("Connect to DRS")
    setRGB(0,110,46)
    digitalWrite(LED1, 1)
    digitalWrite(LED2,0)
    return render_template('LWA.html')
    
#Here we are routing to the success page where the user will be 
#notified of their success in connecting their refrigerator.
@app.route('/success')
def success():
    setText("Fridge Connected to DRS!")
    setRGB(0,128,64)
    digitalWrite(LED1,  0)
    digitalWrite(LED2,  1)

    
    return render_template('success.html')

# Flask uses the run() function to run the application on the local server
# We are making sure it is routing to a https (secured) page.
if __name__ == '__main__':
	context = ('local.crt', 'local.key')
	app.run(debug=True, port=1200, host='127.0.0.1', ssl_context = 'adhoc')




